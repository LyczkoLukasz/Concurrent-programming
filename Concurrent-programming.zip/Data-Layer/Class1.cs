﻿namespace Data_Layer
{
    public class Class1
    {

    }
}
