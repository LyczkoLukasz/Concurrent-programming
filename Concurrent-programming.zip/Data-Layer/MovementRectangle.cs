﻿namespace Data_Layer
{
    public class MovementRectangle
    {
        public double Width { get; set; }
        public double Height { get; set; }
    }
}
