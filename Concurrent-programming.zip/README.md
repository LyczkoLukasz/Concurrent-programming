# Concurrent-programming

## Working Group

| Name Surname (initials) | GUID                                     |
| ----------------------- | ---------------------------------------- |
| Łukasz Łyczko           | "{C20517AD-9159-49CF-8AF1-0172E342E0B1}" |
