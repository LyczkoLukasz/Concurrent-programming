﻿namespace Logic_Layer
{
    public class Class1
    {

    }
}
